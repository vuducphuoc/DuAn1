create proc sp_thongketaisan_2
as begin
	select tenpb,quantity,moneysum 
	from PHONGBAN pb join (select mapb, count(mapb) as 'quantity', sum(nguyengia) as 'moneysum' 
						   from PHIEUBANGIAO bg join TAISAN ts on bg.MATS=ts.MATS
                           group by mapb) pt on pb.mapb=pt.mapb
end
go

