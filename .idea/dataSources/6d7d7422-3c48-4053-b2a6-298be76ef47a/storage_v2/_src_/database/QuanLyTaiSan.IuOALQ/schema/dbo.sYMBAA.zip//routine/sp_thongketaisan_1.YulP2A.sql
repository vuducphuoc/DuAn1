create proc sp_thongketaisan_1
as begin
	SELECT pl.TENPL, COUNT(ts.MATS) as 'SL', SUM(ts.NGUYENGIA) as 'Tong gia tri'
	FROM dbo.TAISAN ts INNER JOIN dbo.PHANLOAI pl on ts.MAPL = pl.ID
	GROUP BY pl.TENPL
END
go

