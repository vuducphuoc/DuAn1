create proc sp_thongketaisanhetkhauhao
  @phanloai int,
  @date_start date = null,
  @date_end date = null

as begin
  BEGIN
    if (@date_start is null )
      BEGIN
        SET @date_start = (SELECT TOP 1 NGAYBDSUDUNG FROM TAISAN order by NGAYBDSUDUNG asc)
        PRINT (@date_start)
      END
    if (@date_end is null )
      BEGIN
        SET @date_end = (SELECT TOP 1 NGAYBDSUDUNG FROM TAISAN order by NGAYBDSUDUNG desc)
        PRINT (@date_end)
    END
    if (@phanloai = 0)
      BEGIN
        SELECT TENTS,TENPL,NGAYBDSUDUNG,THOIGIANKHAUHAO
        FROM TAISAN TS JOIN PHANLOAITAISAN PL ON TS.MAPL=PL.ID
        WHERE (DATEDIFF(DAY,NGAYBDSUDUNG,GETDATE())/365)-THOIGIANKHAUHAO>=0
          AND (NGAYBDSUDUNG between @date_start AND  @date_end)
      END
    else
      BEGIN
        SELECT TENTS,TENPL,NGAYBDSUDUNG,THOIGIANKHAUHAO
        FROM TAISAN TS JOIN PHANLOAITAISAN PL ON TS.MAPL=PL.ID
        WHERE (DATEDIFF(DAY,NGAYBDSUDUNG,GETDATE())/365)-THOIGIANKHAUHAO >= 0
          AND PL.ID = @phanloai  AND (NGAYBDSUDUNG between @date_start AND  @date_end)
      END
  END
end
go

