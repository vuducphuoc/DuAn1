create proc sp_thongketaisan_2
as begin
	SELECT TENPB tenpb, COUNT(TAISAN.MATS) soluong, SUM(CAST(NGUYENGIA AS BIGINT)) tongtaisan FROM dbo.PHONGBAN
				LEFT JOIN PHIEUBANGIAO on PHONGBAN.MAPB = PHIEUBANGIAO.MAPB
				LEFT JOIN TAISAN on PHIEUBANGIAO.MATS = TAISAN.MATS
	GROUP BY TENPB
end

exec sp_thongketaisan_2

--proc #3
if OBJECT_ID('sp_hetkhauhao') is not null
	drop proc sp_hetkhauhao
go

